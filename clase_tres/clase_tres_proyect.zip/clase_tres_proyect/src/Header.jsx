import './App.css';

function Header() {
    return (
        <div className='Header'>
          <h3>Evermore</h3>
        </div>
    )
}

export default Header;
