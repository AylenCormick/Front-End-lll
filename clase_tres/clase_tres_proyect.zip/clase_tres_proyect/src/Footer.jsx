import './App.css';

function Footer() {
    return (
        <div className='Footer'>
        <h3>TSU</h3>
        </div>
)
}

export default Footer;